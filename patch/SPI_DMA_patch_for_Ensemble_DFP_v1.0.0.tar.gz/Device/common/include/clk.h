/* Copyright (C) 2022 Alif Semiconductor - All Rights Reserved.
 * Use, distribution and modification of this code is permitted under the
 * terms stated in the Alif Semiconductor Software License Agreement
 *
 * You should have received a copy of the Alif Semiconductor Software
 * License Agreement with this file. If not, please write to:
 * contact@alifsemi.com, or visit: https://alifsemi.com/license
 *
 */

#ifndef CLK_H_
#define CLK_H_

#include <peripheral_types.h>

extern volatile uint32_t HFRC_CLK;
extern volatile uint32_t HFXO_CLK;
extern volatile uint32_t HFOSC_CLK;
extern volatile uint32_t SOC_REFCLK;
extern volatile uint32_t AXI_CLOCK;
extern volatile uint32_t AHB_CLOCK;
extern volatile uint32_t APB_CLOCK;
extern volatile uint32_t RTSS_HE_CLK;
extern volatile uint32_t RTSS_HP_CLK;
extern uint32_t SystemCoreClock;

#define SYST_PCLK               get_APB_CLOCK()
#define I2C_PERIPHERAL_CLOCK    get_APB_CLOCK()
#define CDC200_PIXCLK           get_AXI_CLOCK()

#define PLL_CLK1                800000000
#define PLL_CLK3                480000000


static inline uint32_t get_HFRC_CLK() {
    return HFRC_CLK;
}

static inline void set_HFRC_CLK(uint32_t clk) {
    HFRC_CLK = clk;
}

static inline uint32_t get_HFXO_CLK() {
    return HFXO_CLK;
}

static inline void set_HFXO_CLK(uint32_t clk) {
    HFXO_CLK = clk;
}

static inline uint32_t get_HFOSC_CLK() {
    return HFOSC_CLK;
}

static inline void set_HFOSC_CLK(uint32_t clk) {
    HFOSC_CLK = clk;
}

static inline uint32_t get_SOC_REFCLK() {
    return SOC_REFCLK;
}

static inline void set_SOC_REFCLK(uint32_t clk) {
    SOC_REFCLK = clk;
}

static inline uint32_t get_AXI_CLOCK() {
    return AXI_CLOCK;
}

static inline void set_AXI_CLOCK(uint32_t clk) {
    AXI_CLOCK = clk;
}

static inline uint32_t get_AHB_CLOCK() {
    return AHB_CLOCK;
}

static inline void set_AHB_CLOCK(uint32_t clk) {
    AHB_CLOCK = clk;
}

static inline uint32_t get_APB_CLOCK() {
    return APB_CLOCK;
}

static inline void set_APB_CLOCK(uint32_t clk) {
    APB_CLOCK = clk;
}

static inline uint32_t get_RTSS_HE_CLK() {
    return RTSS_HE_CLK;
}

static inline void set_RTSS_HE_CLK(uint32_t clk) {
    RTSS_HE_CLK = clk;
#if defined (M55_HE)
    SystemCoreClock = clk;
#endif
}

static inline uint32_t get_RTSS_HP_CLK() {
    return RTSS_HP_CLK;
}

static inline void set_RTSS_HP_CLK(uint32_t clk) {
    RTSS_HP_CLK = clk;
#if defined (M55_HP)
    SystemCoreClock = clk;
#endif
}

static inline void enable_force_peripheral_functional_clk(void)
{
    CLKCTL_PER_SLV->EXPMST0_CTRL |= EXPMST0_CTRL_IPCLK_FORCE;
}

static inline void disable_force_peripheral_functional_clk(void)
{
    CLKCTL_PER_SLV->EXPMST0_CTRL &= ~EXPMST0_CTRL_IPCLK_FORCE;
}

static inline void enable_force_apb_interface_clk(void)
{
    CLKCTL_PER_SLV->EXPMST0_CTRL |= EXPMST0_CTRL_PCLK_FORCE;
}

static inline void disable_force_apb_interface_clk(void)
{
    CLKCTL_PER_SLV->EXPMST0_CTRL &= ~EXPMST0_CTRL_PCLK_FORCE;
}

static inline void enable_cgu_clk160m(void)
{
    CGU->CLK_ENA |= CLK_ENA_CLK160M;
}

static inline void disable_cgu_clk160m(void)
{
    CGU->CLK_ENA &= ~CLK_ENA_CLK160M;
}
static inline void enable_cgu_clk100m(void)
{
    CGU->CLK_ENA |= CLK_ENA_CLK100M;
}

static inline void disable_cgu_clk100m(void)
{
    CGU->CLK_ENA &= ~CLK_ENA_CLK100M;
}

static inline void enable_cgu_clk20m(void)
{
    CGU->CLK_ENA |= CLK_ENA_CLK20M;
}

static inline void disable_cgu_clk20m(void)
{
    CGU->CLK_ENA &= ~CLK_ENA_CLK20M;
}

static inline void enable_cgu_clk38p4m(void)
{
    CGU->CLK_ENA |= CLK_ENA_CLK38P4M;
}

static inline void disable_cgu_clk38p4m(void)
{
    CGU->CLK_ENA &= ~CLK_ENA_CLK38P4M;
}

static inline void enable_gpu_periph_clk(void)
{
    CLKCTL_PER_MST->PERIPH_CLK_ENA |= PERIPH_CLK_ENA_GPU_CKEN;
}

static inline void disable_gpu_periph_clk(void)
{
    CLKCTL_PER_MST->PERIPH_CLK_ENA &= ~PERIPH_CLK_ENA_GPU_CKEN;
}

static inline void enable_sdc_periph_clk(void)
{
    CLKCTL_PER_MST->PERIPH_CLK_ENA |= PERIPH_CLK_ENA_SDC_CKEN;
}

static inline void disable_sdc_periph_clk(void)
{
    CLKCTL_PER_MST->PERIPH_CLK_ENA &= ~PERIPH_CLK_ENA_SDC_CKEN;
}

static inline void enable_usb_periph_clk(void)
{
    CLKCTL_PER_MST->PERIPH_CLK_ENA |= PERIPH_CLK_ENA_USB_CKEN;
}

static inline void disable_usb_periph_clk(void)
{
    CLKCTL_PER_MST->PERIPH_CLK_ENA &= ~PERIPH_CLK_ENA_USB_CKEN;
}

#endif /* CLK_H_ */
